import tkinter as tk
from tkinter import messagebox

# --- LOGIC ---
class Node:
    def __init__(self, v): self.v, self.left, self.right = v, None, None

class BST:
    def __init__(self): self.root = None
    def insert(self, v):
        if not self.root: self.root = Node(v); return True
        return self._ins(self.root, v, 1)
    def _ins(self, n, v, lvl):
        if lvl >= 4: return False
        if v < n.v:
            if not n.left: n.left = Node(v); return True
            return self._ins(n.left, v, lvl + 1)
        elif v > n.v:
            if not n.right: n.right = Node(v); return True
            return self._ins(n.right, v, lvl + 1)
        return False
    def search(self, v): return self._search(self.root, v)
    def _search(self, n, v):
        if not n: return False
        if v == n.v: return True
        return self._search(n.left, v) if v < n.v else self._search(n.right, v)
    
    def get_search_path(self, v):
        path = []
        self._path(self.root, v, path)
        return path
    def _path(self, n, v, path):
        if not n: return
        path.append(n.v)
        if v == n.v: return
        if v < n.v: self._path(n.left, v, path)
        else: self._path(n.right, v, path)

    def get_pre(self): res=[]; self._pre(self.root, res); return res
    def _pre(self, n, r):
        if n: r.append(n.v); self._pre(n.left, r); self._pre(n.right, r)
    def get_ino(self): res=[]; self._ino(self.root, res); return res
    def _ino(self, n, r):
        if n: self._ino(n.left, r); r.append(n.v); self._ino(n.right, r)
    def get_post(self): res=[]; self._post(self.root, res); return res
    def _post(self, n, r):
        if n: self._post(n.left, r); self._post(n.right, r); r.append(n.v)

# --- ABOUT WINDOW ---
def show_about(padre):
    w = tk.Toplevel(padre); w.title("About")
    w.geometry(f"400x250+{(w.winfo_screenwidth()//2)-200}+{(w.winfo_screenheight()//2)-125}")
    w.configure(bg="white"); w.resizable(False, False); w.transient(padre); w.grab_set()
    info = ["Application: Fase4DanielLondoño", "Student: Daniel Esneider Londoño Pancha",
            "Group: 218", "Course: Data Structures - 301305", "UNAD - ECBTI Systems Engineering"]
    for text in info:
        tk.Label(w, text=text, font=("Arial", 10), bg="white", fg="black").pack(pady=5)
    tk.Button(w, text="Accept", bg="#00b4d8", fg="white", font=("Arial", 10, "bold"), command=w.destroy).pack(pady=15)

# --- LOGIN ---
def login():
    v = tk.Tk(); v.title("Fase4DanielLondoño — Login")
    v.geometry(f"450x500+{(v.winfo_screenwidth()//2)-225}+{(v.winfo_screenheight()//2)-250}")
    v.configure(bg="white"); v.resizable(False, False)
    
    menu = tk.Menu(v, font=("Arial", 12, "bold")); v.config(menu=menu)
    menu.add_command(label="About", font=("Arial", 12, "bold"), command=lambda: show_about(v))
    
    tk.Label(v, text="BST Explorer", font=("Forte", 24, "bold"), bg="white", fg="black").pack(pady=14)
    tk.Label(v, text="Binary Search Tree - Phase 4", font=("Forte", 16, "bold"), bg="white", fg="black").pack(pady=14)
    
    f = tk.Frame(v, bg="#f0f0f0", bd=1, relief="solid"); f.pack(pady=10, padx=20, fill="x")
    for t in ["Application: Fase4DanielLondoño", "Student: Daniel Esneider Londoño Pancha", "Course: Data Structures - 301305", "November 22, 2026"]:
        tk.Label(f, text=t, font=("Arial", 10), bg="#f0f0f0", fg="black").pack(anchor="w", padx=10, pady=2)

    tk.Label(v, text="Enter Password", font=("Arial", 8, "bold"), bg="white", fg="black").pack(pady=(20, 5))
    p = tk.Entry(v, show="*", font=("Arial", 14), width=20, justify="center"); p.pack()
    
    def check_login():
        if p.get() == "UNAD":
            v.destroy()
            main()
        else:
            messagebox.showerror("Error", "Incorrect password")

    tk.Button(v, text="Access BST Explorer", bg="#ffd166", fg="black", font=("Arial", 12, "bold"), 
              command=check_login).pack(pady=30)
    
    tk.Label(v, text="UNAD - ECBTI Systems engineering", font=("Arial", 8, "bold"), bg="white", fg="black").pack(pady=6)
    v.mainloop()

# --- MAIN WINDOW ---
def main():
    r = tk.Tk(); r.title("Fase4DanielLondoño — BST Explorer")
    r.geometry(f"1100x450+{(r.winfo_screenwidth()//2)-550}+{(r.winfo_screenheight()//2)-225}")
    r.configure(bg="white"); tree = BST()
    
    tf = tk.Frame(r, bg="white"); tf.pack(side="bottom", fill="x", padx=10, pady=10)
    labels = {}
    for i, title in enumerate(["Pre-order", "In-order", "Post-order"]):
        f = tk.Frame(tf, bg="white", bd=1, relief="solid"); f.grid(row=0, column=i, sticky="nsew", padx=5)
        tk.Label(f, text=title, bg="white", fg="black", font=("Arial", 9, "bold")).pack(anchor="w", padx=5)
        labels[title] = tk.Label(f, text="Empty", bg="white", fg="black", font=("Courier", 9), wraplength=300)
        labels[title].pack(anchor="w", padx=5, pady=5); tf.grid_columnconfigure(i, weight=1)

    lf = tk.Frame(r, bg="white", width=220, highlightbackground="gray", highlightthickness=2)
    lf.pack(side="left", fill="y", padx=10, pady=10); lf.pack_propagate(False)
    tk.Label(lf, text="Controls", font=("Arial", 14, "bold"), bg="white", fg="black").pack(pady=10)
    tk.Label(lf, text="Node Value:", bg="white", fg="black").pack(anchor="w", padx=10)
    val_entry = tk.Entry(lf, font=("Arial", 12)); val_entry.pack(fill="x", padx=10, pady=5)
    
    path_label = tk.Label(lf, text="Search Path: None", bg="white", fg="blue", font=("Arial", 9, "bold"), wraplength=200)
    path_label.pack(anchor="w", padx=10, pady=5)

    rf = tk.Frame(r, bg="white"); rf.pack(side="right", fill="both", expand=True, padx=10, pady=10)
    canvas = tk.Canvas(rf, bg="white", highlightthickness=1, highlightbackground="gray"); canvas.pack(fill="both", expand=True)

    # CORRECCIÓN: draw ahora recibe una lista de nodos del camino
    def draw(n, x, y, dx, hl=None, path_nodes=[]):
        if n:
            if n.left: canvas.create_line(x, y, x-dx, y+70, fill="black"); draw(n.left, x-dx, y+70, dx//2, hl, path_nodes)
            if n.right: canvas.create_line(x, y, x+dx, y+70, fill="black"); draw(n.right, x+dx, y+70, dx//2, hl, path_nodes)
            
            # Lógica de colores
            if n.v == hl:
                c_bg = "#90ee90" # Verde claro (Nodo encontrado)
                c_txt = "black"
            elif n.v in path_nodes:
                c_bg = "#f4a261" # Naranja (Camino recorrido)
                c_txt = "black"
            else:
                c_bg = "black"   # Negro (Nodo normal)
                c_txt = "white"
                
            canvas.create_oval(x-15, y-15, x+15, y+15, fill=c_bg, outline="black") 
            canvas.create_text(x, y, text=str(n.v), fill=c_txt, font=("Arial", 10, "bold"))

    def update(hl=None, path_nodes=[]):
        canvas.delete("all")
        if tree.root: draw(tree.root, 400, 40, 160, hl, path_nodes)
        labels["Pre-order"].config(text=str(tree.get_pre()) if tree.root else "Empty")
        labels["In-order"].config(text=str(tree.get_ino()) if tree.root else "Empty")
        labels["Post-order"].config(text=str(tree.get_post()) if tree.root else "Empty")

    def add():
        try: v = int(val_entry.get())
        except: return messagebox.showerror("Error", "Invalid integer")
        if messagebox.askyesno("Confirmation", f"Do you want to add the node {v}?"):
            if tree.insert(v): 
                val_entry.delete(0, tk.END)
                path_label.config(text="Search Path: None")
                update() # Limpia los colores
            else: messagebox.showwarning("Error", "Max 4 levels or duplicate")

    def search():
        try: v = int(val_entry.get())
        except: return messagebox.showerror("Error", "Invalid integer")
        
        if messagebox.askyesno("Confirmation", f"Do you want to search the node {v}?"):
            if tree.search(v):
                path = tree.get_search_path(v)
                # Quitamos el último nodo de la lista del camino para que no choque con el verde
                path_nodes = path[:-1] 
                
                path_str = " -> ".join(str(num) for num in path)
                path_label.config(text=f"Path: {path_str}")
                update(hl=v, path_nodes=path_nodes) # Pintamos verde el encontrado y naranja el camino
                messagebox.showinfo("Result", f"Node {v} found!")
            else: 
                path_label.config(text="Search Path: Not found")
                messagebox.showinfo("Result", f"Node {v} not found")

    def clear():
        if messagebox.askyesno("Confirmation", "Are you sure you want to clear the entire tree?"):
            tree.__init__()
            path_label.config(text="Search Path: None")
            update()

    def exit_app():
        if messagebox.askyesno("Confirmation", "Are you sure you want to exit?"): r.quit()

    for t, c, cmd in [("Add Node", "#4cc9f0", add), ("Search Node", "#06d6a0", search), ("Clear Tree", "#f4a261", clear), ("Exit", "#e63946", exit_app)]:
        tk.Button(lf, text=t, bg="white", fg="black", font=("Arial", 10, "bold"), bd=2, relief="solid", activebackground=c, command=cmd).pack(fill="x", padx=10, pady=5)
        
    r.mainloop()

if __name__ == "__main__": login()